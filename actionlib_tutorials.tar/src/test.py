#!/usr/bin/env python

import rospy
print(rospy.get_param('nav_to_mine'))
test = input()
rospy.set_param('nav_to_mine', test)
print(rospy.get_param('nav_to_mine'))


